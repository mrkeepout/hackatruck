//
//  ContentView.swift
//  Aula05
//
//  Created by Turma02-11 on 02/06/25.
//

import SwiftUI

struct ContentView: View {
    @State public var nomePlaylist: String = "HackaFM"
    
    //Structs para as musicas
    struct Song : Identifiable{
        var id: Int
        var name : String
        var artist : String
        var capa : String
    }
    
    var arrayMusicas = [
        Song(id: 3, name: "World Hold On - FISHER Rework", artist: "Bob Sinclair, FISHER, Steve Edwards", capa: "bobsinclair"),
        Song(id: 4, name: "Numb Encore", artist: "Linkin Park", capa: "lpCollisionCourse"),
        Song(id: 5, name: "Lost", artist: "Linkin Park", capa: "lpLOST")
    ]
    
    var body: some View {
        ZStack{
            LinearGradient(
                            gradient: Gradient(colors: [.blue, .black]),
                            startPoint: .top,
                            endPoint: .bottom
                        )
                        .ignoresSafeArea()
            VStack {
                Spacer()
                Image("caminhao")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .imageScale(.small)
                    .foregroundStyle(.tint)
                Spacer()
                
                //Informacoes playlist
                HStack {
                    VStack(alignment: .leading) {
                        Text("HackaFM")
                            .font(.title)
                            .bold()
                            .foregroundColor(.white)
                            .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                        Spacer()
                        
                        HStack{
                            Text("HackaSong")
                            
                        }//hstack
                        Spacer()
                    }
                    Spacer() // Empurra tudo para a esquerda
                }
                
                //Informacoes das musicas
                
                HStack{
                    VStack{
                        ForEach(arrayMusicas) { e in
                            NavigationLink(destination: , label: )
                            HStack{
                                Image(e.capa)
                                    .resizable()
                                    .frame(width: 80, height: 80)
                                VStack{
                                    Text(e.name)
                                    Text(e.artist)
                                }
                            }
                        }
                        Spacer()
                    }
                    Spacer()
                }
                .padding()
            }//vstack
            .padding()
        }//zstack
    }//view
}//contentview

#Preview {
    ContentView()
}
