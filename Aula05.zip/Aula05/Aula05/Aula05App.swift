//
//  Aula05App.swift
//  Aula05
//
//  Created by Turma02-11 on 02/06/25.
//

import SwiftUI

@main
struct Aula05App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
