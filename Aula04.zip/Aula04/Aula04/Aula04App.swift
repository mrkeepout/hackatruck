//
//  Aula04App.swift
//  Aula04
//
//  Created by Turma02-11 on 30/05/25.
//

import SwiftUI

@main
struct Aula04App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
