//
//  ContentView.swift
//  Aula03
//
//  Created by Turma02-11 on 28/05/25.
//

import SwiftUI

struct CustomBlackGroupBoxStyle: GroupBoxStyle {
    func makeBody(configuration: Configuration) -> some View {
        VStack(alignment: .leading) {
            configuration.label
                .font(.caption)
                .foregroundColor(.white)
                .padding(.bottom, 2)

            configuration.content
        }
        .padding()
        .background(Color.black)
        .cornerRadius(15)
        .shadow(color: .black.opacity(0.5), radius: 5)
    }
}


struct ContentView: View {
    @State public var distancia: String = "0"
    @State public var tempo: String = "0"
    @State public var velocidade: String = "0,00 km/h"
    @State public var animais: String = "interrogacao"
    @State public var corFundo: String = "Fundo"
    
    
    var body: some View {
        VStack {
            VStack(spacing: 15) {
                Text("Digite a distância (km): ")
                    .font(.headline)
                
                TextField("0 ", text: $distancia)
                    .keyboardType(.decimalPad)
                    .textContentType(.oneTimeCode)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)
                
                Text("Digite o tempo (h):")
                    .font(.headline)
                
                TextField("0 ", text: $tempo)
                    .keyboardType(.decimalPad)
                    .textContentType(.oneTimeCode)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)
                
                Button {
                    calcularVelocidade()
                } label: {
                    Text("Calcular")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(.vertical, 12)
                        .padding(.horizontal, 25)
                        .background(Color.black)
                        .cornerRadius(10)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.gray, lineWidth: 2)
                        )
                }
                .padding(.top, 20)
                
                Spacer()
                
                Text("\(velocidade)").font(.title)
                    
                
                Image("\(animais)")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 220)
                    .clipShape(Circle())
                    .padding(.horizontal)
                
                Spacer()
                
                GroupBox {
                    VStack(alignment: .leading, spacing: 5) {
                        HStack {
                            Text("TARTARUGA")
                            Spacer()
                            Text("(0 - 9.9km/h)")
                            Circle()
                                .fill(Color("Tartaruga"))
                                .frame(width: 20, height: 20)
                        }
                        HStack {
                            Text("ELEFANTE")
                            Spacer()
                            Text("(10 - 29.9km/h)")
                            Circle()
                                .fill(Color("Elefante"))
                                .frame(width: 20, height: 20)
                        }
                        HStack {
                            Text("AVESTRUZ")
                            Spacer()
                            Text("(30 - 69.9km/h)")
                            Circle()
                                .fill(Color("Avestruz"))
                                .frame(width: 20, height: 20)
                        }
                        HStack {
                            Text("LEÃO")
                            Spacer()
                            Text("(70 - 89.9km/h)")
                            Circle()
                                .fill(Color("Leao"))
                                .frame(width: 20, height: 20)
                        }
                        HStack {
                            Text("GUEPARDO")
                            Spacer()
                            Text("(90 - 130km/h)")
                            Circle()
                                .fill(Color("Guepardo"))
                                .frame(width: 20, height: 20)
                        }
                    }
                    .foregroundColor(.white)
                    .padding(5)
                }
                .groupBoxStyle(CustomBlackGroupBoxStyle())
                .padding(.horizontal) //
            }
            .padding()
            .background(Color(corFundo)
            .ignoresSafeArea())
        }
    }
    
    private func calcularVelocidade() {
        let dist = Double(distancia) ?? 0.0
        let temp = Double(tempo) ?? 0.0
        
        if temp != 0 {
            let resultadoVelocidade = dist / temp
            self.velocidade = String(format: "%.2f km/h", resultadoVelocidade)
            
            if resultadoVelocidade >= 0 && resultadoVelocidade <= 9.9{
                self.animais = String("tartaruga")
                self.corFundo = String("Tartaruga")
            }else if resultadoVelocidade >= 10 && resultadoVelocidade <= 29.9{
                self.animais = String("elefante")
                self.corFundo = String("Elefante")
            }else if resultadoVelocidade >= 30 && resultadoVelocidade <= 69.9{
                self.animais = String("avestruz")
                self.corFundo = String("Avestruz")
            }else if resultadoVelocidade >= 70 && resultadoVelocidade <= 89.9{
                self.animais = String("leao")
                self.corFundo = String("Leao")
            }else if resultadoVelocidade >= 90 && resultadoVelocidade <= 130{
                self.animais = String("guepardo")
                self.corFundo = String("Guepardo")
            }
            
            
            
        } else {
            self.velocidade = "Erro - Digite algum valor"
            self.animais = "interrogacao"
        }
    }
}

#Preview {
    ContentView()
}
