//
//  ContentView.swift
//  Aula03
//
//  Created by Turma02-11 on 28/05/25.
//

import SwiftUI

// MARK: - Custom GroupBoxStyle for compatibility and control
struct CustomBlackGroupBoxStyle: GroupBoxStyle {
    func makeBody(configuration: Configuration) -> some View {
        VStack(alignment: .leading) {
            configuration.label
                .font(.caption) // Apply font to label from within the style
                .foregroundColor(.white) // Ensure label text is white
                .padding(.bottom, 2) // Small padding below label

            configuration.content
        }
        .padding() // Padding inside the GroupBox content area
        .background(Color.black) // Your black background
        .cornerRadius(15) // Rounded corners
        .shadow(color: .black.opacity(0.5), radius: 5) // Shadow
    }
}


struct ContentView: View {
    @State public var distancia: String = ""
    @State public var tempo: String = ""
    @State public var velocidade: String = ""
    
    var body: some View {
        VStack {
            VStack(spacing: 15) {
                Text("Digite a distância (km): ")
                    .font(.headline)
                
                TextField("Digite a distância: ", text: $distancia)
                    .keyboardType(.decimalPad)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)
                
                Text("Digite o tempo (h):")
                    .font(.headline)
                
                TextField("Digite o tempo (h): ", text: $tempo)
                    .keyboardType(.decimalPad)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)
                
                Button {
                    calcularVelocidade()
                } label: {
                    Text("Calcular")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(.vertical, 12)
                        .padding(.horizontal, 25)
                        .background(Color.black)
                        .cornerRadius(10)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.gray, lineWidth: 2)
                        )
                }
                .padding(.top, 20)
                
                Spacer()
                
                Text("\(velocidade) km/h")
                
                Image("interrogacao") // Certifique-se de que a imagem existe nos seus Assets.xcassets
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 200)
                    .clipShape(Circle())
                    .padding(.horizontal)
                
                Spacer()
                
                GroupBox {
                    VStack(alignment: .leading, spacing: 5) {
                        HStack {
                            Text("TARTARUGA")
                            Spacer()
                            Text("(0 - 9.9km/h)")
                            Circle() // Keep circles inside for the example
                                .fill(Color("Tartaruga")) // Use explicit fill
                                .frame(width: 20, height: 20)
                        }
                        HStack {
                            Text("ELEFANTE")
                            Spacer()
                            Text("(10 - 29.9km/h)")
                            Circle()
                                .fill(Color("Elefante"))
                                .frame(width: 20, height: 20)
                        }
                        HStack {
                            Text("AVESTRUZ")
                            Spacer()
                            Text("(30 - 69.9km/h)")
                            Circle()
                                .fill(Color("Avestruz"))
                                .frame(width: 20, height: 20)
                        }
                        HStack {
                            Text("LEÃO")
                            Spacer()
                            Text("(70 - 89.9km/h)")
                            Circle()
                                .fill(Color("Leao"))
                                .frame(width: 20, height: 20)
                        }
                        HStack {
                            Text("GUEPARDO")
                            Spacer()
                            Text("(90 - 130km/h)")
                            Circle()
                                .fill(Color("Guepardo"))
                                .frame(width: 20, height: 20)
                        }
                    }
                    .foregroundColor(.white) // Apply white foreground to all text inside content
                    .padding(5) // Inner padding for GroupBox content
                }
                .groupBoxStyle(CustomBlackGroupBoxStyle()) // <--- Use your custom style here!
                .padding(.horizontal) // Padding to keep GroupBox from edges
            }
            .padding()
            .background(Color.gray.ignoresSafeArea())
        }
        .onTapGesture {
            hideKeyboard()
        }
    }
    
    private func calcularVelocidade() {
        let dist = Double(distancia) ?? 0.0
        let temp = Double(tempo) ?? 0.0
        
        if temp != 0 {
            let resultadoVelocidade = dist / temp
            self.velocidade = String(format: "%.2f", resultadoVelocidade)
        } else {
            self.velocidade = "Erro: Tempo zero"
        }
    }
    
    private func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}

#Preview {
    ContentView()
}
