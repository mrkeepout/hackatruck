//
//  Aula03App.swift
//  Aula03
//
//  Created by Turma02-11 on 28/05/25.
//

import SwiftUI

@main
struct Aula03App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
