//
//  Aul06App.swift
//  Aul06
//
//  Created by Turma02-11 on 03/06/25.
//

import SwiftUI

@main
struct Aul06App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
